const errorHandler = (err, req, res, next) => {

}

module.exports = {
  errorHandler,
}
