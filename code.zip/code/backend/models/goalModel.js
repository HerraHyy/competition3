const mongoose = require('mongoose')

const goalSchema = mongoose.Schema(
  
)

module.exports = mongoose.model('Goal', goalSchema)
