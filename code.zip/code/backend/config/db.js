const mongoose = require('mongoose')

const connectDB = async () => {
  console.log("Hello from connectDB!");
}

module.exports = connectDB
